define(function(){
    return {
        pageGroups: [{"id":"86258125-f8db-c7be-4242-e2438927eb30","name":"Default group","pages":[{"id":"a51b44c7-0ba1-fd02-584b-bdbe3dbbddb5","name":"Items table view"},{"id":"f24e2166-bd59-a6c8-4946-beeb3d29a902","name":"Items tile view"},{"id":"fd7159a0-369f-93f0-3861-437c8023b9d0","name":"Create new item"},{"id":"9ab55570-7477-da7d-510b-e1ebcbbcdd97","name":"Edit item"},{"id":"f9b7fd4f-22c3-d9d6-0641-97ada3fea066","name":"Edit item - Delete confirmation"}]}],
        downloadLink: "//services.ninjamock.com/html/htmlExport/download?shareCode=VN8HS&projectName=Frontend developer test task",
        startupPageId: 0,

        forEachPage: function(func, thisArg){
        	for (var i = 0, l = this.pageGroups.length; i < l; ++i){
                var group = this.pageGroups[i];
                for (var j = 0, k = group.pages.length; j < k; ++j){
                    var page = group.pages[j];
                    if (func.call(thisArg, page) === false){
                    	return;
                    }
                }
            }
        },
        findPageById: function(pageId){
        	var result;
        	this.forEachPage(function(page){
        		if (page.id === pageId){
        			result = page;
        			return false;
        		}
        	});
        	return result;
        }
    }
});
